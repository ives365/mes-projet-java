package TP;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

public class Publication extends Etudiant{
	private float pourcent;
	
	Publication(){}


	public Publication(float pourcent) {
		super();
		this.pourcent = pourcent;
	}
	


	public Publication(String nom, String postNom, String prenom, String matricule, String proomotion, float pourcent) {
		super(nom, postNom, prenom, matricule, proomotion);
		// TODO Auto-generated constructor stub
		this.pourcent = pourcent;
	}


	public float getPourcent() {
		return pourcent;
	}

	public void setPourcent(float pourcent) {
		this.pourcent = pourcent;
	}
	
	public void serialisePub(List<Publication> pub) {
		
		try {
			FileOutputStream fileOut = new FileOutputStream("gestionCotes/publication.ser");
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(pub);
			out.close();
			fileOut.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public ArrayList deserialiser() {
		Object et;
		ArrayList ets = new ArrayList();
		
		ArrayList etsTri = new ArrayList();
	
		try {
			FileInputStream fileIn = new FileInputStream("gestionCotes/publication.ser");
			ObjectInputStream in = new ObjectInputStream(fileIn);
			et = in.readObject();
			ets.add(et);
			
			in.close();
			fileIn.close();
		}catch(IOException i) {
			i.printStackTrace();
			
	
		
	   }catch(ClassNotFoundException e) {
		  
		   e.printStackTrace();
	   }
		Collections.sort(ets);
		
		return ets;
	
	}

	@Override
	public String toString() {
		return matricule + " " + getNom() + " " + getPostNom() + " " + getPrenom() +  " " + proomotion + " " + pourcent + "%" + '\n';
	}
	
	public void print() {
		for(Object et : deserialiser()) System.out.println(et);
	}
	
	public void tri(Hashtable<Float,  Publication> hash) {
		List keyList = new ArrayList(hash.keySet());
		List mesDonnees = new  ArrayList();
		Collections.sort(keyList, Collections.reverseOrder());
		Enumeration en = hash.elements();
		String et;
		for(Object i : keyList) {
			for(Map.Entry entry : hash.entrySet()) {
				if(i == entry.getKey()) mesDonnees.add(hash.get(i));
				}
		              
			
	       }
		serialisePub(mesDonnees);
		
      }
	

}
