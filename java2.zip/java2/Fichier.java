package TP;

import java.io.IOException;

public interface Fichier {
	public void write(String etudiant) throws IOException;
	public void read();
}
