package TP;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class FenC extends JFrame implements ActionListener{
	
	 JButton reset = new JButton("CE");
     JButton b7 = new JButton("7");
     JButton b8 = new JButton("8");
     JButton b9 = new JButton("9");
     JButton div = new JButton("/");
     JButton b4 = new JButton("4");
     JButton b5 = new JButton("5");
     JButton b6 = new JButton("6");
     JButton m = new JButton("X");
     JButton b3 = new JButton("3");
     JButton b2 = new JButton("2");
     JButton b1 = new JButton("1");
     JButton b = new JButton("-");
     JButton v = new JButton(".");
     JButton zero = new JButton("0");
     JButton eg = new JButton("=");
     JButton plus = new JButton("+");
     
     
     JLabel historicLabel = new JLabel();
     
     JTextField display = new JTextField();
	
	 FenC(){
		// Fenetre
				JFrame fen=new JFrame("Calculatrice");
		        fen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		        fen.setLocationRelativeTo(null);
		       
		        JPanel pnlHead = new JPanel(new BorderLayout());
		        pnlHead.add( display, BorderLayout.NORTH);
		        pnlHead.add( reset, BorderLayout.CENTER);
		        
		        JPanel panPrincipale = new JPanel();
		        GridLayout layP = new GridLayout(0, 4);
		        panPrincipale.setLayout(layP);
		       
		        
		        
		        JPanel conteneur = new JPanel(new BorderLayout());
		        
		      
		        
		       

		        
		        panPrincipale.add(b7);
		        panPrincipale.add(b8);
		        panPrincipale.add(b9);
		        panPrincipale.add(div);
		        panPrincipale.add(b4);
		        panPrincipale.add(b5);
		        panPrincipale.add(b6);
		        panPrincipale.add(m);
		        panPrincipale.add(b1);
		        panPrincipale.add(b2);
		        panPrincipale.add(b3);
		        panPrincipale.add(b);
		        panPrincipale.add(v);
		        panPrincipale.add(zero);
		        panPrincipale.add(eg);
		        panPrincipale.add(plus);
		        
		          
		        reset.setForeground(Color.red);
		        b7.setForeground(Color.BLUE);
		        b8.setForeground(Color.BLUE);
		        b9.setForeground(Color.BLUE);
		        div.setForeground(Color.BLUE);
		        b4.setForeground(Color.BLUE);
		        b.setForeground(Color.BLUE);
		        b4.setForeground(Color.BLUE);
		        b6.setForeground(Color.BLUE);
		        b5.setForeground(Color.BLUE);
		        b6.setForeground(Color.BLUE);
		        b1.setForeground(Color.BLUE);
		        b2.setForeground(Color.BLUE);
		        b3.setForeground(Color.BLUE);
		        v.setForeground(Color.BLUE);
		        zero.setForeground(Color.BLUE);
		        eg.setForeground(Color.BLUE);
		        plus.setForeground(Color.BLUE);
		        m.setForeground(Color.BLUE);
		       
		      
		        
		        
		        
		        conteneur.add(BorderLayout.NORTH, pnlHead);
		        conteneur.add(BorderLayout.CENTER, panPrincipale);
		        
		        reset.addActionListener(this);
		        zero.addActionListener(this);
		        b1.addActionListener(this);
		        b2.addActionListener(this);
		        b3.addActionListener(this);
		        b4.addActionListener(this);
		        b5.addActionListener(this);
		        b6.addActionListener(this);
		        b7.addActionListener(this);
		        b8.addActionListener(this);
		        b9.addActionListener(this);
		        b.addActionListener(this);
		        div.addActionListener(this);
		        eg.addActionListener(this);
		        m.addActionListener(this);
		        plus.addActionListener(this);
		        v.addActionListener(this);
		        
		   
		        
		        
		      
		       
		        fen.setContentPane(conteneur);
		       
		        
		        //fen.pack();
		        fen.setSize(300, 280);
		        fen.setVisible(true);

		
	}

	
	
	 public void actionPerformed(ActionEvent e) {
	        Object source = e.getSource();
	        String c = e.getActionCommand();
	        if (source == reset)
	            sReset();
	        else if ("0123456789.".indexOf(c) >= 0) {
	        	nbre(c);
	        	
	        }
	        else{
	        	CalculOperator(c);
	        }
	        
	    }

	    boolean premierChiffre = true;
	    double number = 0.0;
	    String operator = "=";
	    
	    
		
	    public void nbre(String key) {
	        if (premierChiffre)
	            display.setText(key);
	        else if (!key.equals("."))
	            display.setText(display.getText() + key);
	        else if (display.getText().indexOf(".") < 0)
	            display.setText(display.getText() + ".");
	        premierChiffre = false;
	        
	    }

	    public void sReset() {
	        display.setText("0");
	        premierChiffre = true;
	        operator = "=";
	    }
	    
	    public void CalculOperator(String cmd) {
			double dDisplay = Double.valueOf(display.getText());
			switch(operator){
				case "+": 
					number += dDisplay;
					break;
				case "-": 
					number -= dDisplay;  
					break;
				case "X": 
					number *= dDisplay;
					break;
				case "/": 
					number /= dDisplay;
					break;
				case "=": 
					number = dDisplay; 
					break;
			}
			display.setText(String.valueOf(number));
	        operator = cmd;
	       
	        premierChiffre = true;
	    }
	    
		
	    
		

	 
	 public static void main(String[] args) {
		 FenC f = new FenC();
			
		}

}
