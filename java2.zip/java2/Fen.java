package TP;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Fen {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Etudiant et = new Etudiant();
		Cotes cote = new Cotes();
		int id = 1;
		
		JFrame fen=new JFrame("Gestion de cotes");
        fen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fen.setLocationRelativeTo(null);
        //JLabel
        JLabel lblNom = new JLabel("Nom");
        JLabel lblPost = new JLabel("Postnom");
        JLabel lblPre = new JLabel("Prenom");
        JLabel lblMat = new JLabel("Matricule");
        JLabel lblPro = new JLabel("Promotion");
        JLabel lblCote1 = new JLabel("Cote moyenne");
        JLabel lblCote2 = new JLabel("Cote examen");
        JLabel msgConfirm = new JLabel();
   
       
       
        //  JTextField 
        JTextField txtNom = new JTextField();
        JTextField txtPost = new JTextField();
        JTextField txtPre = new JTextField();
        JTextField txtMat = new JTextField();
        JTextField txtPro = new JTextField();
        JTextField txtCote1 = new JTextField();
        JTextField txtCote2 = new JTextField();
    
        
        //JButton
        JButton btnAnnuler=new JButton("Annuler");
        JButton btnValider = new JButton("Enregistrer");
         //JPanel
        JPanel panPrincipale=new JPanel();
        GridLayout layP=new GridLayout(0, 2);
        panPrincipale.setLayout(layP);
        panPrincipale.add(lblNom);
        panPrincipale.add(txtNom);
        panPrincipale.add(lblPost);
        panPrincipale.add(txtPost);
        panPrincipale.add(lblPre);
        panPrincipale.add(txtPre);
        panPrincipale.add(lblMat);
        panPrincipale.add(txtMat);
        panPrincipale.add(lblPro);
        panPrincipale.add(txtPro);
        panPrincipale.add(lblCote1);
        panPrincipale.add(txtCote1);
        panPrincipale.add(lblCote2);
        panPrincipale.add(txtCote2);
        
        
        JPanel p2 = new JPanel();
        p2.add(btnAnnuler);
        p2.add(btnValider);
        
        panPrincipale.add(msgConfirm);
        panPrincipale.add(p2);
        
        JMenuBar barMenu=new JMenuBar();
        JMenu menuFichier=new JMenu("Fichier");
        JMenu menuEdition=new JMenu("Edition");
        
        JCheckBoxMenuItem it1 = new JCheckBoxMenuItem("Fichier.txt");
        it1.setMnemonic(KeyEvent.VK_C);
        JCheckBoxMenuItem it2 = new JCheckBoxMenuItem("Fichier.xml");
        it2.setMnemonic(KeyEvent.VK_C);
        menuFichier.add(it1);
        menuFichier.add(it2);
        
        barMenu.add(menuFichier);
        barMenu.add(menuEdition);
        
        btnValider.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				int id = 1;
				
				AbstractButton btn = (AbstractButton)e.getSource();
				boolean t2 = it2.getModel().isSelected();
				
				boolean t1 = it1.getModel().isSelected();
				String etudiant = "", c = "";
				if(t1) {
					etudiant += "Nom : " + txtNom.getText() + ", Postnom : " + txtPost.getText() + ", Prenom : " + txtPre.getText() + ", Matricule : " + txtMat.getText() + ", Matricule : " + txtPro.getText() + '\n';
					c += "Nom : " + txtNom.getText() + ", Postnom : " + txtPost.getText() + ", Prenom : " + txtPre.getText() + ", Matricule : " + txtMat.getText() + ", Matricule : " + txtPro.getText() + "Moyenne : " +txtCote1.getText()+ "Examen : " + txtCote2.getText() + '\n';

					
					try {
						et.write(etudiant);
						cote.write(c);
						msgConfirm.setForeground(Color.GREEN);
						msgConfirm.setText("Les données ont été ajouter avec succès");
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					txtNom.setText("");
					txtPost.setText("");
					txtPre.setText("");
					txtMat.setText("");
					txtPro.setText("");
					txtCote1.setText("");
					txtCote2.setText("");
					
				}
				if(t2) {
					et.fichierXml(txtNom.getText(), txtPost.getText(), txtPre.getText(), txtMat.getText(), txtPro.getText(), 0, id++);
					msgConfirm.setForeground(Color.GREEN);
					msgConfirm.setText("Les données ont été ajouter avec succès");
					txtNom.setText("");
					txtPost.setText("");
					txtPre.setText("");
					txtMat.setText("");
					txtPro.setText("");
					txtCote1.setText("");
					txtCote2.setText("");
					
				}
				
				
				
				
			}
		});
        
        fen.setContentPane(panPrincipale);
        fen.setJMenuBar(barMenu);
       // fen.setSize(400, 200);
       fen.pack();
        fen.setVisible(true);	
        

	}

}
