package seance;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class InterfaceGraphique {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame fen  = new JFrame("Test Dessin");
		fen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel pan = new JPanel() {
			@Override
			protected void paintComponent(Graphics g) {
				super.paintComponent(g);
				g.setColor(Color.BLACK);
				g.fillRect(100,100, 255, 250);
				g.setColor(Color.RED);
				g.fillArc(10, 10, 200, 100, 200, 300);
				
			}
		};
		fen.setContentPane(pan);
		fen.setSize(700, 700);
		fen.setVisible(true);

	}

}
