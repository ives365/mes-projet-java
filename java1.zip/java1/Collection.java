package seance;

import java.util.ArrayList;
import java.util.Iterator;

import notionDeClass.*;

public class Collection {

	public static void main(String[] args) {
		/**************************************** ArrayList************************************************************** */
		ArrayList<Personne> test = new ArrayList();
		test.add(new Personne("Cogolaise", 1987));
		test.add(new Personne("Angolaise", 1587));
		test.add(new Personne("Cammerounaise", 1987));
		
		test.get(0).setAdress("Lubumbashi");
		test.get(test.size() - 1).setAdress("Ville de Luanda");
		Personne pp = new Personne("Gabonaise", 1990);
		test.set(1, pp);
		
		
		//Parcours avec for each
		
		for(Personne p : test)System.out.println(p.getaNaiss() + " " + p.getNationalite() + " " + p.getAdress());
		
		Iterator<Personne> it = test.iterator();
		Personne p1;
		
		while(it.hasNext()) {
			p1 = it.next();
			System.out.println(p1.getaNaiss() + " " + p1.getNationalite() + " " + p1.getAdress());
		}
		
		/******************************************** Map ********************************************************************/

	}

}
