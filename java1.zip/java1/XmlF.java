package seance;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;



public class XmlF {

	public static void main(String[] args) {
		// TODO Auto-generated method stubD
		DocumentBuilderFactory db = DocumentBuilderFactory.newInstance();
		try {
			DocumentBuilder docB = db.newDocumentBuilder();
			Document doc = docB.newDocument();
			// element racine
			Element racine = doc.createElement("repertoire");
			doc.appendChild(racine);
			// element contact
			Element contact = doc.createElement("contact");
			racine.appendChild(contact);
			
			//attribut de l'element contact
			Attr attr = doc.createAttribute("id");
			attr.setValue("1");
			contact.setAttributeNode(attr);
			
			// le nom 
			Element nom = doc.createElement("nom");
			nom.appendChild(doc.createTextNode("codeur"));
			racine.appendChild(nom);
			// le prenom
			
			Element prenom = doc.createElement("prenom");
			nom.appendChild(doc.createTextNode("java"));
			racine.appendChild(prenom);
			
			TransformerFactory transforme = TransformerFactory.newInstance();
			Transformer tr;
			try {
				tr = transforme.newTransformer();
			
			DOMSource source = new DOMSource(doc);
			StreamResult re = new StreamResult(new File("src/monfichier.xml"));
			
				tr.transform(source, re);
			} catch (TransformerConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			} catch (TransformerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			
			System.out.println("Fichier sauvergardé avec succès");
			
			
			
			
			
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
