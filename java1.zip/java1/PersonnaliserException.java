package seance;

public class PersonnaliserException extends Exception{
	PersonnaliserException(){
		super("le nombre est inférieur à 0 ");
	}
	

}
