package seance;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Seance3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i;
		Scanner n = new Scanner(System.in);
		
		
		/*try {
			System.out.print("Veulleur saisir le nombre entier svp : ");
			i = n.nextInt();
			System.out.println(i);
		}catch(InputMismatchException j) {
			System.out.println("Il faut entrer un nombre entier svp");
			j.printStackTrace();
			
		}catch(ArithmeticException e) {
			System.out.println("Il y a une erreur ! ! !");
			e.printStackTrace();
		}
		finally {
			System.out.print("finally");
		}
		
		if(i == 0) {
			throw new PersonnaliserException();
		}*/
		
		try {
			
			System.out.print("Veulleur saisir le nombre entier svp : ");
			i = n.nextInt();
			
		}catch(InputMismatchException k) {
			System.out.println("Encore une erreur ! ! !");
			k.printStackTrace();
		}catch(Exception e) {
			System.out.println("Il y a une erreur ! ! !");
			e.printStackTrace();
		}
		
		

	}

}
