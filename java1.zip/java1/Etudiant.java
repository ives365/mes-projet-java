package seance;
import notionDeClass.*;

public class Etudiant extends Personne{
	String  matricule;
	String promotion;
	String filiere;
	String ecole;

	public Etudiant(String nationalite, int aNaiss, String matricule, String promotion, String filiere, String ecole) {
		super(nationalite, aNaiss);
		this.matricule = matricule;
		this.promotion = promotion;
		this.filiere = filiere;
		this.ecole = ecole;
	}

	public Etudiant(String nationalite, int aNaiss) {
		super(nationalite, aNaiss);
		// TODO Auto-generated constructor stub
	}

	public String getMatricule() {
		return matricule;
	}

	public void setMatricule(String matricule) {
		this.matricule = matricule;
	}

	public String getPromotion() {
		return promotion;
	}

	public void setPromotion(String promotion) {
		this.promotion = promotion;
	}

	public String getFiliere() {
		return filiere;
	}

	public void setFiliere(String filiere) {
		this.filiere = filiere;
	}

	public String getEcole() {
		return ecole;
	}

	public void setEcole(String ecole) {
		this.ecole = ecole;
	}
	

}
