package com.chat.serveurclient;

import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;




public class Serveur {
	static String reponse;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final ServerSocket serveur;
		final Socket client;
		final BufferedReader in;
		final PrintWriter out;
		final Scanner sc = new Scanner(System.in);
		
		try {
			serveur = new ServerSocket(1025);
			client = serveur.accept();
			out = new PrintWriter(client.getOutputStream());
			in = new BufferedReader(new InputStreamReader(client.getInputStream()));
			Thread envoi = new Thread(new Runnable() {
				String msg;
				int i = 0;
				@Override
				public void run() {
					// TODO Auto-generated method stub
								
					while(true) {
						//msg = sc.nextLine();
						
						msg = "Veuiller taper ce que vous cherchez par exemple : personne, voiture";
						out.println(msg + i++);
						out.flush();
						out.println(afficher());
						msg = sc.nextLine();
						out.flush();
						
					}
				}
			});
			envoi.start();
			
			Thread recevoir = new Thread(new Runnable() {
				String msg;
				@Override
				public void run() {
					// TODO Auto-generated method stub
					
					try {
						msg = in.readLine();
						// tant ke le client est connecté
						while(msg != null) {
							System.out.println("Client : " + msg);
							reponse = msg;
							msg = in.readLine();
						}
						System.out.println("Client déconnecté");
						out.close();
						client.close();
						serveur.close();
						
					}catch(IOException e) {
						e.printStackTrace();
					}
				}
			});
			
			recevoir.start();
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		

	}
	
	public static List<Personne> afficher() {
		List<Personne> person = new ArrayList<Personne>();
	     Connection con = null;
		 Statement st = null;
		 final String url = "jdbc:mysql://localhost:3308/test?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";;
		final String login = "root";
		final String pwd = "";
		ResultSet  ree = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url, login, pwd);
			st = (Statement) con.createStatement();
			
			String reSql  = "SELECT * FROM personne";
			ree = st.executeQuery(reSql);
			while(ree.next()) {
				person.add(new Personne(ree.getString("nom"), ree.getString("prenom"), ree.getString("adresse"),ree.getString("idpers")));
				
			}
		} catch (ClassNotFoundException j){
			System.out.println("Veuillez lancer votre  serveur svp!  " + j);
			
		} catch (SQLException e) {
			System.out.println("La connexion a échoué, Veuillez lancer votre  serveur svp! " + e);
		}
		
		return person;
	}
	

}
