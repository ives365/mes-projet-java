package Views;

import application.Main;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class RootLayoutController {
	private Main main;
	private PersonOvervieController controller = new PersonOvervieController();
	
	public void setMain(Main main) {
		this.main = main;
	}
	
	@FXML
	private void actualiser() {
		Main main2 = new Main();
	    main2.getPersonDate().get(1);
		
	}
	
	@FXML
	private void help() {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("AdressApp");
		alert.setHeaderText("About");
		alert.setContentText("Ives Ngamulume :  email : yvesn314@gmail.com");
		alert.showAndWait();
	}
	
	@FXML
	private void handleBirthdayStatistic() {
		main.showBirthdayStastics();
	}
	
	@FXML
	private void handExit() {
		System.exit(0);
	}

}
