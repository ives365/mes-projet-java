package Views;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.time.LocalDate;


import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

@SuppressWarnings("serial")
public class Person implements Serializable{
	/**
	 * 
	 */
	
	private final StringProperty nom;
	private final StringProperty prenom;
	private final StringProperty adresse;
	private final StringProperty idp;
	private final ObjectProperty<LocalDate> datenaiss;
	
	public Person() {
		this(null, null, null, null);
	}
	
	
	public Person(String nom, String prenom, String adresse, String idp) {
		this.nom = new SimpleStringProperty(nom);
		this.prenom = new SimpleStringProperty(prenom);
		this.idp = new SimpleStringProperty(idp);
		this.adresse = new SimpleStringProperty(adresse);
		this.datenaiss = new SimpleObjectProperty<LocalDate>(LocalDate.of(1999, 2, 21));
		
	}
	
	public String getNom() {
		return nom.get();
	}
	
	public void setNom(String nom) {
		this.nom.set(nom);
	}
	
	public StringProperty nomProperty() {
		return nom;
	}
	
	public String getPrenom() {
		return prenom.get();
	}
	
	public void setPrenom(String prenom) {
		this.prenom.set(prenom);
	}
	
	public StringProperty prenomProperty() {
		return prenom;
	}
	
	public String getAdresse() {
		return adresse.get();
	}
	public void setAdresse(String adresse) {
		this.adresse.set(adresse);
	}
	public LocalDate getDatenaiss() {
		return datenaiss.get();
	}
	public StringProperty adresseProperty() {
		return adresse;
	}
	
	
	public void setDatenaiss(LocalDate datenaiss) {
		this.datenaiss.set(datenaiss);
	}
	
	public ObjectProperty<LocalDate> datenaissProperty(){
		return datenaiss;
	}
	

	public String getIdp() {
		return idp.get();
	}
	
	public void setIdp(String idp) {
		this.idp.set(idp);
	}
	private void writeObject(ObjectOutputStream out) throws IOException {
		out.defaultWriteObject();
		out.writeUTF(getNom());
		out.writeUTF(getNom());
		out.writeUTF(getAdresse());
		out.writeUTF(getIdp());
		
	}
	
	private void readObject(ObjectInputStream in) throws ClassNotFoundException, IOException {
		in.defaultReadObject();
	}

}
