package Views;

import java.io.IOException;

import java.util.Stack;

import Model.RequeteDB;
import application.Main;
import javafx.beans.Observable;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import util.DateUtil;

public class PersonOvervieController {
	@FXML
	private TableView<Person> personTable;
	@FXML
	private TableColumn<Person, String> nomCol;
	@FXML
	private TableColumn<Person, String> prenomCol;
	
	@FXML
	private Label nomLabel;
	@FXML
	private Label prenomLabel;
	@FXML
	private Label adresseLabel;
	@FXML
	private Label datenaiss;
	
	static int INDEXTB;
	
	private Main main;
	private RequeteDB re = new RequeteDB();
	
	public PersonOvervieController() {}
	
	@FXML
	private void initialize() {
		nomCol.setCellValueFactory(cellData -> cellData.getValue().nomProperty());
		prenomCol.setCellValueFactory(cellData -> cellData.getValue().prenomProperty());
		
		showPersonDetails(null);
		personTable.getSelectionModel().selectedItemProperty().addListener(
				(Observable, oldvalue, newValue) -> showPersonDetails(newValue)
				
				);
		personTable.refresh();
		
	}
	private void showPersonDetails(Person person) {
		if(person != null) {
			nomLabel.setText(person.getNom());
			prenomLabel.setText(person.getPrenom());
			adresseLabel.setText(person.getAdresse());
			datenaiss.setText(DateUtil.format(person.getDatenaiss()));
			
		}else {
			nomLabel.setText("");
			prenomLabel.setText("");
			adresseLabel.setText("");
			datenaiss.setText("");
		}
	}
	
	@FXML
	private void handleSupprimer() {
		int selectedIndex = personTable.getSelectionModel().getSelectedIndex();
		
		if(selectedIndex >= 0) {
			System.out.println(Integer.parseInt(personTable.getItems().get(selectedIndex).getIdp()));
			int i = Integer.parseInt(personTable.getItems().get(selectedIndex).getIdp());
			
			personTable.getItems().remove(selectedIndex);
			re.delete(i);
		}
		
		else {
			Alert alert = new Alert(AlertType.WARNING);
			alert.initOwner(main.getPrincipal());
			alert.setTitle("No selection");
			alert.setHeaderText("aucune personne n'est selectionnée");
			alert.setContentText("Veuillez selectionner une personne dans la table ! ! !");
			
			alert.showAndWait();
		}
	}
	
	@FXML
	private void handleNewPerson() {
		main = new Main();
		Person tempPerson = new Person();
		boolean okClicked = main.showPersonEditDialog(tempPerson);
		
		if(okClicked) {
			main.getPersonDate().add(tempPerson);
			
			
		}
	}
	

	
	
	@FXML
	private void handleEditPerson() throws IOException {
		Person selectedPerson = personTable.getSelectionModel().getSelectedItem();	
		INDEXTB = personTable.getSelectionModel().getSelectedIndex() + 1;
		
		if(selectedPerson != null) {
			boolean okClicked = main.showPersonEditDialog(selectedPerson);
			if(okClicked) {
				showPersonDetails(selectedPerson);
				
			}
			
		}else {
			Alert alert = new Alert(AlertType.WARNING);
			alert.initOwner(main.getPrincipal());
			alert.setTitle("No Selection");
			alert.setHeaderText("No Person Selected");
			alert.setContentText("Veuillez selectionner une personne dans la table");
			
			alert.showAndWait();
		}
	}
	
	public void setMain(Main main) {
		this.main = main;
		personTable.setItems(main.getPersonDate());
	}
	
	
}
