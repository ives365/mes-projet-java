package Views;

import java.io.BufferedReader;


import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;



import Connexion.Voiture;
import Model.Personne;
import Model.RequeteDB;
import application.Main;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import util.DateUtil;

public class PersonEditDialogCOntroller {
	@FXML
	private TextField txtNom;
	@FXML
	private TextField txtPrenom;
	@FXML
	private TextField txtAdresse;
	@FXML
	private TextField txtDatenaiss;
	@FXML
	private TextField txtId;
	
	private Stage dialogStage;
	public static Person person;
	static Personne PERSON =  new Personne();
	private boolean okClicked = false;
	private RequeteDB re = new RequeteDB();
	
	
	
	@FXML
	public void initialize() {
		
	}
	public void setDialogStage(Stage dialogStage) {
		this.dialogStage = dialogStage;
	}
	
	public void setPerson(Person person) {
		this.person = person;
		txtNom.setText(person.getNom());
		txtPrenom.setText(person.getPrenom());
		txtAdresse.setText(person.getAdresse());
		txtId.setText(person.getIdp());
		txtDatenaiss.setText(DateUtil.format(person.getDatenaiss()));
		txtDatenaiss.setPromptText("dd.mm.yyyy");
	}
	public boolean isOkClicked() {
		return okClicked;
	}
	
	
	
	@FXML
	public void handleOk() {
		if(isInputValid()) {
			person.setNom(txtNom.getText());
			PERSON.setNom(txtNom.getText());
			person.setPrenom(txtPrenom.getText());
			PERSON.setPrenom(txtPrenom.getText());
			person.setAdresse(txtAdresse.getText());
			PERSON.setAdresse(txtAdresse.getText());
			person.setIdp(txtId.getText());
			
			person.setDatenaiss(DateUtil.parse(txtDatenaiss.getText()));
			PERSON.setDatenaiss(String.valueOf(DateUtil.parse(txtDatenaiss.getText())));
			
			System.out.println(txtId.getText());
			
			if(PersonOvervieController.INDEXTB != 0) re.modifier(person, Integer.parseInt(txtId.getText()));
			else {
				//re.ajouter(person);
				
				(new Client()).main(null);
				 
				
			}
			
			okClicked = true;
			dialogStage.close();
		}
	}
	
	@FXML
	public void handleCancel() {
		dialogStage.close();
	}
	private boolean isInputValid() {
		// TODO Auto-generated method stub
		String errorMessage = "";
		if(txtNom.getText() == null || txtNom.getText().length() == 0)errorMessage += "le nom n'est pas valide ! \n";
		if(txtPrenom.getText() == null || txtPrenom.getText().length() == 0)errorMessage += "le prenom n'est pas valide ! \n";
		if(txtAdresse.getText() == null || txtAdresse.getText().length() == 0)errorMessage += "l'adresse n'est pas valide ! \n";
		if(PersonOvervieController.INDEXTB != 0) {
			if(txtId.getText() == null || txtAdresse.getText().length() == 0)errorMessage += "l'id n'est pas valide ! \n";
		}else txtId.setText("7");
		if(txtDatenaiss.getText() == null || txtDatenaiss.getText().length() == 0) {
			errorMessage += "la date de naissance n'est pas valide ! \n";
		}else {
			if(!DateUtil.validDate(txtDatenaiss.getText())) {
				errorMessage += "la date de naissance n'est pas valide ! \n";
			}
			if(errorMessage.length() == 0) {
				return true;
			}
			else {
				Alert alert = new Alert(AlertType.ERROR);
				alert.initOwner(dialogStage);
				alert.setTitle("invalide");
				alert.setHeaderText("svp! les informations sont incorrectes");
				alert.setContentText(errorMessage);
				
				alert.showAndWait();
				
			}
		}

		
		return false;
	}
	
	public static class Client {

		
	    public static void main(String[] args) {
	        
//	        Voiture voiture = new Voiture("Carina","mini voiture","9000AB RDC");
	        
	        try {
	            
	            Socket client = new Socket("127.0.0.4",1026);
	            System.out.println("Connecté au "+client.getInetAddress().getHostAddress());
	            
	            new ThreadClavier(client).start();
	            new ThreadEcouter(client).start();
	        
	        } catch (IOException ex) {
	            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
	        }
	    }
	    
	    static class ThreadClavier extends Thread{
	        Socket client;
	        
	        
	    

	        public ThreadClavier(Socket client) {
	            this.client = client;
	        }

	        @Override
	        public void run() {
	            ObjectOutputStream objStream = null;
	            
	            try {
	            	
	             
	                objStream = new ObjectOutputStream(client.getOutputStream());
	                objStream.writeObject(PERSON);
	                objStream.flush();
	                
	                try {
	                    this.sleep((long)0);
	                } catch (InterruptedException ex) {
	                    Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
	                }
	            } catch (IOException ex) {
	                Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
	            } /*finally {
	                try {
	                    //objStream.close();
	                } catch (IOException ex) {
	                    Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
	                }
	            }*/
	        }
	    }
	    static class ThreadEcouter extends Thread{
	        Socket client;

	        private ThreadEcouter(Socket _client) {
	            client = _client;
	        }

	        @Override
	        public void run() {
	            try {
	                BufferedReader lect = new BufferedReader(
	                        new InputStreamReader(client.getInputStream()));
	                System.out.println();
	            } catch (IOException ex) {
	                Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
	            }
	        }
	        
	        
	    }
	    
	}

}
