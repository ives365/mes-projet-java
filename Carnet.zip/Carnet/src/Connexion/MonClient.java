package Connexion;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.List;

import Model.Personne;

public class MonClient {
	public static void main(String[] arg) throws ClassNotFoundException {
		int portEcouteServeur = 1025;
		BufferedReader lecteurFichier;
		BufferedReader entree ;
		 PrintWriter  sortie;
		String ligne ;
		Socket socket;
		ObjectInputStream oinStream = null;
		try {
			socket = new Socket("127.0.0.4",1025);
			oinStream = new ObjectInputStream(socket.getInputStream());
			System.out.println("Oky"+ socket);
			List<Personne> person = (List<Personne>)oinStream.readObject();
             System.out.println(person.toString());
             PrintWriter printer = new PrintWriter(socket.getOutputStream());
             //p.setNom(person.get(0));
             printer.println(person.toString());
			
			
			
			socket.close();
		}
		catch(FileNotFoundException exc) {
			System.out.println("Fichier introuvable");
		}
		catch(UnknownHostException exc) {
				System.out.println("destinataire inconnu");
		}
		catch(IOException exc) {
				System.out.println("probleme d'entree-sortie"+exc);
		}
	}

}
