package Connexion;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.Serializable;


public class Voiture implements Serializable{
    private String marque;
    private String model;
    private String numPlaquet;

    public Voiture(String marque, String model, String numPlaquet) {
        this.marque = marque;
        this.model = model;
        this.numPlaquet = numPlaquet;
    }

    Voiture() {
        
    }

    public String getMarque() {
        return marque;
    }

    public String getModel() {
        return model;
    }

    public String getNumPlaquet() {
        return numPlaquet;
    }

    public void setMarque(String marque) {
        this.marque = marque;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setNumPlaquet(String numPlaquet) {
        this.numPlaquet = numPlaquet;
    }

    @Override
    public String toString() {
        return "Voiture{" + "marque=" + marque + ", model=" + model + ", numPlaquet=" + numPlaquet + '}';
    }
    
    
    
}
