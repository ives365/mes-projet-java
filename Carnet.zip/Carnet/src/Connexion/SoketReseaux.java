package Connexion;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.sun.jdi.StackFrame;

import Model.Personne;
import Model.RequeteDB;
import Views.Person;
import Views.PersonEditDialogCOntroller.Client;
import application.Main;
import javafx.collections.ObservableList;


public class SoketReseaux {

   public static int CON;
	
	
    public static void main(String[] args) {
    	//int  CON;
        try {
        	
            ServerSocket serv = new ServerSocket(1026);
              
                System.out.println("Lancement du server "+serv.getInetAddress().getHostAddress());
                Socket service = serv.accept();
                
                new ThreadService(service).start();
                //new ThreadClavier(service).start();
            

        } catch (IOException ex) {
            Logger.getLogger(SoketReseaux.class.getName()).log(Level.SEVERE, null, ex);
        }finally {
        	CON = 1;
        }
        
    }
    
   
    
    static class ThreadService extends Thread{
        Socket client;
        Person p = null;
        static RequeteDB re;

        public ThreadService(Socket client) {
            this.client = client;
           
        }

        
		@Override
        public void run() {
            ObjectInputStream oinStream = null;
            try {
                oinStream = new ObjectInputStream(client.getInputStream());
                try {
                    System.out.print("Client >>"+client.getInetAddress().getHostAddress());
                    System.out.print("Connecté au port >>"+client.getPort());
                    Personne person = (Personne)oinStream.readObject();
                    System.out.println(person.toString());
                    PrintWriter printer = new PrintWriter(client.getOutputStream());
                    //p.setNom(person.get(0));
                    printer.println(person.toString());
                    ajouter(new Personne(person.getNom(), person.getPrenom(), person.getAdresse(), person.getDatenaiss()));
                    
                    this.sleep(0);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(SoketReseaux.class.getName()).log(Level.SEVERE, null, ex);
                } catch (InterruptedException ex) {
                    Logger.getLogger(SoketReseaux.class.getName()).log(Level.SEVERE, null, ex);
                }
            } catch (IOException ex) {
                Logger.getLogger(SoketReseaux.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                try {
                    oinStream.close();
                } catch (IOException ex) {
                    Logger.getLogger(SoketReseaux.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            
        }
		
		public static void ajouter(Personne person) {
		     Connection con = null;
			 Statement st = null;
			 final String url = "jdbc:mysql://localhost:3308/test?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";;
			final String login = "root";
			 final String pwd = "";
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				con = DriverManager.getConnection(url, login, pwd);
				st = (Statement) con.createStatement();
				
				String reSql = "INSERT INTO personne"
						+ "(`nom`, `prenom`, `adresse`, `datenaiss`) "
						+ "VALUES(?, ?, ?, ?)";
				
					PreparedStatement pre = con.prepareStatement(reSql);
					 pre.setString(1, person.getNom());
					 pre.setString(2, person.getPrenom());
					 pre.setString(3, person.getAdresse());
					 pre.setObject(4, person.getDatenaiss());
					 pre.execute();
					 con.close();
				
			} catch (ClassNotFoundException j){
				System.out.println("Veuillez lancer votre  serveur svp!  " + j);
				
			} catch (SQLException e) {
				System.out.println("La connexion a échoué, Veuillez lancer votre  serveur svp! " + e);
			}
		}
		
    }
    
}
