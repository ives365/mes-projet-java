package application;
	
import java.io.File;


import java.io.IOException;
import java.net.Socket;
import java.util.prefs.Preferences;

import Connexion.SoketReseaux;
import Model.RequeteDB;
import Views.BirthdayStasticsControlleur;
import Views.Person;
import Views.PersonEditDialogCOntroller;
import Views.PersonOvervieController;
import Views.RootLayoutController;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.fxml.FXMLLoader;


public class Main extends Application {
	private Stage principal;
	BorderPane layout;
	AnchorPane rootLayout;
	RequeteDB re;
	public static int CLIENT;
	
	
	public Main() {
		 re = new RequeteDB();	 
				
	}
	
	
	public Stage getPrincipal() {
		return principal;
	}


	public void setPrincipal(Stage principal) {
		this.principal = principal;
	}


	public ObservableList<Person> getPersonDate(){
		return re.afficher();
		
	}
	
	
	
	
	@Override
	public void start(Stage primaryStage) {
		try {
			principal = primaryStage;
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getClassLoader().getResource("Views/rcine.fxml"));
			layout = (BorderPane)loader.load();
			FXMLLoader loader2 = new FXMLLoader();
			
			loader2.setLocation(getClass().getClassLoader().getResource("Views/fh.fxml"));
			layout.setCenter(loader2.load());
			
			PersonOvervieController controller = loader2.getController();
			controller.setMain(this);
			Scene scene = new Scene(layout);
		
		     
			principal.setTitle("Carnet d'adresse");
			principal.getIcons().add(new Image("file:ressource/img/icon.png"));
			principal.setScene(scene);
			principal.show();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean showPersonEditDialog(Person person) {
		try {
			
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getClassLoader().getResource("Views/PersonEditDialog.fxml"));
			AnchorPane page = (AnchorPane)loader.load();
			Stage dialogStage = new Stage();
			
			dialogStage.setTitle("Ajouter une personne");
			dialogStage.initModality(Modality.WINDOW_MODAL);
			dialogStage.initOwner(principal);
			Scene scene = new Scene(page);
			dialogStage.setScene(scene);
			
			PersonEditDialogCOntroller controller = loader.getController();
			controller.setDialogStage(dialogStage);
			controller.setPerson(person);
			
			dialogStage.showAndWait();
			
			
			return controller.isOkClicked();
			
			
			
		}catch(IOException e) {
			e.printStackTrace();
			
			return false;
		}
	}
	
	public void initRootLayout() {
		
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getClassLoader().getResource("Views/rcine.fxml"));
			layout = (BorderPane) loader.load();
			
			Scene scene = new Scene(layout);
			principal.setScene(scene);
			
			
			RootLayoutController controller = loader.getController();
			controller.setMain(this);
			
			principal.show();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void showBirthdayStastics() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getClassLoader().getResource("Views/BirthdayStatic.fxml"));
			AnchorPane page = (AnchorPane) loader.load();
			Stage dialogStage = new Stage();
			
			dialogStage.setTitle("Birthday Statistics");
			dialogStage.initModality(Modality.WINDOW_MODAL);
			dialogStage.initOwner(principal);
			Scene scene = new Scene(page);
			dialogStage.setScene(scene);
			
			BirthdayStasticsControlleur controller = loader.getController();
			controller.setPersonData(getPersonDate());
			dialogStage.show();
			
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	
	public File getPersonFilePath() {
		Preferences prefs = Preferences.userNodeForPackage(getClass());
		String filePath = prefs.get("filePath", null);
		if(filePath != null) return new File(filePath);
		else return null;
	}
	
	public void setPersonFilePath(File file) {
		Preferences prefs = Preferences.userNodeForPackage(getClass());
		if(file != null) {
			prefs.put("filePath", file.getPath());
			
			principal.setTitle("AddressApp");
		}
	}
	
	
	
	public static void main(String[] args) {
		launch(args);
		
	}
}
