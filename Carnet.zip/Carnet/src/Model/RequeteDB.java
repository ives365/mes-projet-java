package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import Views.Person;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class RequeteDB {
	private Connection con = null;
	private Statement st = null;
	private final String url = "jdbc:mysql://localhost:3308/test?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";;
	private final String login = "root";
	private final String pwd = "";
	private ObservableList<Person> personDate = FXCollections.observableArrayList();
	public RequeteDB(){
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			this.con = DriverManager.getConnection(url, login, pwd);
			this.st = (Statement) this.con.createStatement();
			
		} catch (ClassNotFoundException j){
			System.out.println("Veuillez lancer votre  serveur svp!  " + j);
			
		} catch (SQLException e) {
			System.out.println("La connexion a échoué, Veuillez lancer votre  serveur svp! " + e);
		}
	}
	
	public ObservableList<Person> afficher(){
		ResultSet re = null;
		int i = 1;
		String reSql  = "SELECT * FROM personne";
		try {
			re = this.st.executeQuery(reSql);
			while(re.next()) {
				this.personDate.add(new Person(re.getString("nom"), re.getString("prenom"), re.getString("adresse"), String.valueOf(re.getInt("idpers"))));
			}
			
		return this.personDate;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				
				this.con.close();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return null;

  } 
	
	public void ajouter(Person person) {
		String reSql = "INSERT INTO personne"
				+ "(`nom`, `prenom`, `adresse`, `datenaiss`) "
				+ "VALUES(?, ?, ?, ?)";
		try {
			PreparedStatement pre = this.con.prepareStatement(reSql);
			 pre.setString(1, person.getNom());
			 pre.setString(2, person.getPrenom());
			 pre.setString(3, person.getAdresse());
			 pre.setObject(4, person.getDatenaiss());
			 pre.execute();
			 con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void modifier(Person person, int idpers) {
		
		try {
			String reSql  = "UPDATE `personne` SET `nom`= ?,`prenom`= ?,`adresse`= ?,`datenaiss`=? WHERE `idpers`= ?";
			PreparedStatement pre = this.con.prepareStatement(reSql);
			pre.setString(1, person.getNom());
			pre.setString(2, person.getPrenom());
			pre.setString(3, person.getAdresse());
			pre.setObject(4, person.getDatenaiss());
			pre.setInt(5, idpers);
			pre.execute();
			this.con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
   public void delete(int idperson){
		
		try {
			String reSql  = "DELETE FROM `personne` WHERE idpers = ?";
		     PreparedStatement pre = this.con.prepareStatement(reSql);
			 pre.setInt(1, idperson);
			 pre.execute();
			 
			
			
		} catch (SQLException e) {
			System.out.println("Veuilez taper une valeur entière convenable");
			e.printStackTrace();
		}
	}
	public void fermetureBdd(){
		try {
		    this.st.close();
			this.con.close();
			
		} catch (SQLException e) {
			System.out.println("La connexion a échoué, erreur   " + e);

		} 
	}
}
