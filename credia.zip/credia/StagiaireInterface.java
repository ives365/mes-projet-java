package credia;

public interface StagiaireInterface {
	public String coder(String langage);

}
