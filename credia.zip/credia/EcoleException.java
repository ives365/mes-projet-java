package credia;

public class EcoleException extends Exception{
	EcoleException(){
		super("Désolé on a juste besoin des étudiants d'ESIS");
	}

}
